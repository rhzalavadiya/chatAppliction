'use client';
import Image from "next/image";
import { FiSend } from "react-icons/fi";
import { useState, useEffect, useRef, use } from "react";
import { motion } from "framer-motion";

const contacts = [
  {
    id: 1, name: "Emma Thompson", initials: "EM",
    lastmsg: 'I’ve sent you the last project files. Please check them out.',
    time: '10:30 AM', online: true,
  },
  {
    id: 2, name: 'Michael Johnson', initials: 'MJ',
    lastMsg: 'Are we still meeting for coffee',
    time: 'Yesterday', online: false
  },
  {
    id: 3, name: 'Sophia Lee', initials: 'SL',
    lastMsg: 'The design team loved your pre...',
    time: 'Yesterday', online: false
  },
  {
    id: 4, name: 'Robert Brown', initials: 'RB',
    lastMsg: 'Can you review the budget prop...',
    time: 'Tuesday', online: false
  },
  {
    id: 5, name: 'Amelia Wilson', initials: 'AW',
    lastMsg: 'Thanks for your help with the cli...',
    time: 'May 27', online: false
  },
  {
    id: 6, name: 'Daniel Martinez', initials: 'DM',
    lastMsg: 'Let’s schedule a call to discus...',
    time: 'May 25', online: false
  },
];
const boatReplies = [
  'Got it, thanks!',
  'Looking forward to it!',
  'Let me check and get back to you.',
  'Sounds good.',
  'Sure, will do!',
];
export default function ChatApp() {
  const [activeContact, setActiveContact] = useState(contacts[0]);
  const [messages, setMessages] = useState([
    { from: 'them', text: 'Oh, I almost forgot - do you have the latest version of the client presentation?', time: '12:05 PM' },
    { from: 'me', text: 'I’ve just sent it to your email. Let me know if you need anything else!', time: '12:15 PM', status: 'Sent' },
    { from: 'them', text: 'Got it, thanks! I’ll review it before our lunch. See you soon!', time: '12:20 PM' },
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [typing, setTyping] = useState(false);
  const chatEndRef = useRef(null);
  const handleSend = () => {
    if (!newMessage.trim()) return;
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages(prev => [...prev, { from: 'me', text: newMessage, time: now, status: 'Sent' }]);
    setNewMessage('');
    setTyping(true);
    setTimeout(() => {
      const botReply = boatReplies[Math.floor(Math.random() * boatReplies.length)];
      const replyTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setMessages(prev => [...prev, { from: 'them', text: botReply, time: replyTime }]);
      setTyping(false);
    }, 2000)
  };
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  return (
    <div className="flex h-screen">
      {/* Sidebar */}

      <div className="w-1/4 min-w-[250px] border-r border-gray-200 p-4 overflow-y-auto hidden sm:block">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-10 h-10 relative">
            <Image
              src="/logo.png" 
              alt="Logo"
              fill
              className="rounded-full object-cover"
            />
          </div>
          <h1 className="text-xl font-semibold">Chats</h1>
        </div>

        {contacts.map(contact => (
          <div key={contact.id} onClick={() => setActiveContact(contact)}
            className={`flex items-center gap-3 p-2 rounded cursor-pointer hover:bg-gray-100 ${activeContact.id === contact.id ? 'bg-gray-100' : ''}`}>
            <div className="bg-gray-200 rounded-full w-10 h-10 flex items-center justify-center font-bold text-sm">
              {contact.initials}
            </div>
            <div className="flex-1">
              <div className="flex justify-between">
                <span className="font-medium text-sm">{contact.name}</span>
                <span className="text-xs text-gray-500">{contact.time}</span>
              </div>
              <p className="text-xs text-gray-600 truncate w-48">{contact.lastMsg}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Chat Window */}

      <div className="flex-1 flex flex-col">

        {/* Top Nav */}

        <div className="sticky top-0 z-10 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gray-200 rounded-full w-10 h-10 flex items-center justify-center font-bold text-sm">
              {activeContact.initials}
            </div>
            <div>
              <h2 className="font-medium text-sm">{activeContact.name}</h2>
              {activeContact.online && <p className="text-xs text-green-500">Online</p>}
            </div>
          </div>
          <div className="bg-indigo-600 text-white rounded-full px-4 py-2 text-xs">CL</div>
        </div>

        {/* Chat Messages */}

        <div className="flex-1 p-4 overflow-y-auto space-y-3">
          {messages.map((msg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`max-w-md ${msg.from === 'me' ? 'ml-auto text-white bg-indigo-600' : 'bg-gray-100 text-black'} p-3 rounded-xl text-sm relative`}
            >
              {msg.text}
              <div className="text-[10px] mt-1 text-right">
                {msg.time} {msg.from === 'me' && <span>• {msg.status}</span>}
              </div>
            </motion.div>
          ))}
          {typing && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-xs text-gray-500">Typing...</motion.div>}
          <div ref={chatEndRef} />
        </div>

        {/* Chat Input */}
        
        <div className="border-t border-gray-200 p-4 flex items-center gap-2">
          <input
            type="text"
            placeholder="Type a message"
            className="flex-1 border border-gray-300 rounded-full px-4 py-2 text-sm focus:outline-none"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <button onClick={handleSend} className="text-indigo-600 text-xl">
            <FiSend />
          </button>
        </div>
      </div>
    </div>
  );
}
